<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

require 'database.php';
$db = new Database();
$con = $db->connect();


$sql = "SELECT * FROM tblstudent WHERE id = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $_SESSION['id']);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Courses</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">


</head>
<body>
<?php require 'master.php';?>

<h2>My Courses</h2>

<?php
$user_id = $_SESSION['id'];

if (isset($_POST['remove_class_id'])) {
    $class_id = $_POST['remove_class_id'];

    $delete = $con->prepare("DELETE FROM registrations WHERE user_id = ? AND class_id = ?");
    $delete->bind_param("ii", $user_id, $class_id);
    $delete->execute();

    echo "<p class='text-success'>Course removed successfully.</p>";
}

$sql = "SELECT c.class_id, c.class_name, c.class_description, c.credits, c.instructor, c.semester
        FROM registrations r
        JOIN classes c ON r.class_id = c.class_id
        WHERE r.user_id = ?";

$stmt = $con->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();


while ($row = $result->fetch_assoc()) {
    echo "
        <div class='card mb-3'>
            <div class='card-body'>
                <h4 class='card-title'>{$row['class_name']}</h4>
                <p><strong>Description:</strong> {$row['class_description']}</p>
                <p><strong>Credits:</strong> {$row['credits']}</p>
                <p><strong>Instructor:</strong> {$row['instructor']}</p>
                <p><strong>Semester:</strong> {$row['semester']}</p>

                <form method='POST'>
                    <input type='hidden' name='remove_class_id' value='{$row['class_id']}'>
                    <button type='submit' class='btn btn-danger'>Remove Course</button>
                </form>
            </div>
        </div>
    ";
}
?>


<?php require_once 'footer.php';?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>