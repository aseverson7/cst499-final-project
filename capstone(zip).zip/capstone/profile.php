<?php
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
 
    if (!isset($_SESSION['id'])) {
        header("Location: login.php");
        exit();
    }

   require 'database.php';
    $db = new Database();
    $con = $db->connect();

    $sql = "SELECT * FROM tblstudent WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $_SESSION['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title> Profile Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">


</head>
<body>
<?php require 'master.php';?>

    <div class="container mt-4">
        <h1>My Profile</h1>
        <table class="table table-bordered">
            <tr><th>First Name</th><td><?= $student['firstName']?></td></tr>
            <tr><th>Last Name</th><td><?= $student['lastName']?></td></tr>
            <tr><th>Email</th><td><?= $student['email']?></td></tr>
            <tr><th>Password</th><td><?= $student['password']?></td></tr>
            <tr><th>Address</th><td><?= $student['address']?></td></tr>
            <tr><th>Phone</th><td><?= $student['phone']?></td></tr>

        </table>
    </div>

<?php require_once 'footer.php';?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>