<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

require 'database.php';
$db = new Database();
$con = $db->connect();


$sql = "SELECT * FROM tblstudent WHERE id = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $_SESSION['id']);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Enroll Here</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">


</head>
<body>
<?php require 'master.php';?>

<h2>Available Classes</h2>

<?php

if (isset($_POST['class_id'])) {
    $class_id = $_POST['class_id'];
    $user_id = $_SESSION['id'];

    $insert = $con->prepare("INSERT INTO registrations (user_id, class_id, date_registered) VALUES (?, ?, NOW())");
    $insert->bind_param("ii", $user_id, $class_id);
    $insert->execute();

    echo "<p class='text-success'>You have successfully enrolled in the class!</p>";
}

$classes = $con->query("SELECT * FROM classes");

while ($row = $classes->fetch_assoc()) {
    echo "
        <form method='POST'>
            <input type='hidden' name='class_id' value='{$row['class_id']}'>
            <p>{$row['class_name']}</p>
            <button type='submit'>Enroll</button>
        </form>
    ";
}

?>



<?php require_once 'footer.php';?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>