<?php
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title> Login Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">

</head>
<body>
<?php require 'master.php';
?>

<div class="container text-center mt-5">
    <h1>Login</h1>

    <?php
    if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <? $_SESSION['error']; ?>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php 
endif; ?>

    <form action="authenticate.php" method="post" class="mx-auto" style="max-width: 400px;">
        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" name="email" id="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password:</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Login</button>

        <p class="register-link">Don't have an account? <a href="registration.php" class="form-link">Register Here</a></p>

    </form>
</div>
<?php require_once 'footer.php';?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>
