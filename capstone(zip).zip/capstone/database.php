<?php
class Database {

    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "student_registration";

    public function connect() {
        $con = new mysqli($this->servername, $this->username, $this->password, $this->dbname);

        if ($con->connect_error) {
        die ("Connection failed: " . $con->connect_error);
        }
return $con;
    }
    public function executeSelectQuery($con, $sql) {
        $result = $con->query($sql);
        return $result;
    }
    public function executeQuery($con, $sql) {
        if ($con->query($sql) === true) {
            return true;
        } else {
            return false;
        }
    }
}
?>