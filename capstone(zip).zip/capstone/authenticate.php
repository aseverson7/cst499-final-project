<?php

session_start();

require 'database.php';

$db = new Database();
$con = $db->connect();

if (!isset($_POST['email'], $_POST['password'])) {
    header("Location: login.php");
    exit;
}

$email = strtolower(trim($_POST['email']));
$password = $_POST['password'];

$sql = "SELECT * FROM tblstudent WHERE email = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows===1) {
    $row = $result->fetch_assoc();

    if (password_verify($password, $row['password'])) {
        $_SESSION['id'] = $row['id'];
        $_SESSION['email'] = $row['email'];

        header("Location: profile.php");
        exit;
    }
}

$_SESSION['error'] = "Invalid email or password";
header("Location: login.php");
exit;

?>
